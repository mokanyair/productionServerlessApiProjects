import json
import boto3
import os
import uuid

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_NAME'])

def lambda_handler(event, context):
    method = event['requestContext']['http']['method']

    if method == "POST":
        body = json.loads(event['body'])
        item_id = str(uuid.uuid4())

        table.put_item(Item={
            "id": item_id,
            "data": body
        })

        return {
            "statusCode": 200,
            "body": json.dumps({"id": item_id})
        }

    elif method == "GET":
        response = table.scan()
        return {
            "statusCode": 200,
            "body": json.dumps(response["Items"])
        }